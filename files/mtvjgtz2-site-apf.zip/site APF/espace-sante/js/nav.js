/* ===================================================================
   nav.js — En-tête et menu latéral communs à "Mon espace santé".
   Réutilise le même système de comptes que le site ameli (js/auth.js).
   =================================================================== */

function renderEspaceSanteNav(activeTab) {
  const user = requireAuth();
  if (!user) return;

  const headerMount = document.getElementById("header-mount");
  const sidebarMount = document.getElementById("sidebar-mount");
  if (!headerMount || !sidebarMount) return;

  const initiale = (user.nom || "?").charAt(0).toUpperCase();

  headerMount.innerHTML = `
    <div class="bandeau-atelier">
      SITE D'ENTRAÎNEMENT — <span>ceci n'est pas le site officiel monespacesante.fr. Aucune donnée n'est envoyée, tout reste sur cet ordinateur.</span>
    </div>
    <header class="es-header">
      <a class="es-logos" href="../portail.html" title="Retour à l'accueil du portail" style="text-decoration:none;">
        <div class="es-logo-am">
          <div class="es-logo-icon">AM</div>
          <div class="es-logo-am-text">l'Assurance<br>Maladie</div>
        </div>
        <div class="es-divider"></div>
        <div class="es-logo-mes"><span class="l1">MON</span><span class="l1">ESPACE</span><span class="l2">SANTÉ</span></div>
      </a>
      <div class="es-header-right">
        <div class="es-bell">🔔</div>
        <div class="es-user"><div class="avatar">${user.prenom ? user.prenom.charAt(0) : "?"}</div>${user.prenom || ""} ${initiale}.</div>
        <button class="es-logout" id="es-btn-logout">Se déconnecter</button>
      </div>
    </header>
  `;

  const items = [
    { href: "accueil.html", tab: "accueil", ico: "🏠", label: "Accueil" },
    { href: "profil-medical.html", tab: "profil", ico: "👤", label: "Profil médical" },
    { href: "vaccinations.html", tab: "vaccinations", ico: "💉", label: "Vaccinations" },
    { href: "documents.html", tab: "documents", ico: "📁", label: "Documents" },
    { href: "messagerie.html", tab: "messagerie", ico: "✉️", label: "Messagerie" },
    { href: "prevention.html", tab: "prevention", ico: "🩺", label: "Prévention" },
    { href: "agenda.html", tab: "agenda", ico: "📅", label: "Agenda" },
    { href: "catalogue-services.html", tab: "catalogue", ico: "▦", label: "Catalogue de services" },
    { href: "../carte-vitale-app.html", tab: "cartevitale", ico: "📱", label: "Carte Vitale" }
  ];

  sidebarMount.innerHTML = items.map(i => `
    <a href="${i.href}" class="${activeTab === i.tab ? "active" : ""}">
      <span class="ico">${i.ico}</span>${i.label}
    </a>
  `).join("");

  document.getElementById("es-btn-logout").addEventListener("click", logout);

  return user;
}
