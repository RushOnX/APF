/* ===================================================================
   nav.js — Construit l'en-tête et le menu communs aux pages connectées.
   =================================================================== */

function renderHeaderNav(activeTab) {
  const user = requireAuth();
  if (!user) return;

  const mount = document.getElementById("header-nav-mount");
  if (!mount) return;

  mount.innerHTML = `
    <div class="bandeau-atelier">
      SITE D'ENTRAÎNEMENT — <span>ceci n'est pas le site officiel ameli.fr. Aucune donnée n'est envoyée, tout reste sur cet ordinateur.</span>
    </div>

    <header class="site-header">
      <a class="logo-block" href="portail.html" title="Retour à l'accueil du portail" style="text-decoration:none;">
        <div class="logo-icon">AM</div>
        <div>
          <div class="logo-text-main">l'Assurance Maladie<br><span class="logo-text-sub">Agir ensemble, protéger chacun</span></div>
        </div>
        <div class="compte-ameli">Compte ameli</div>
      </a>
      <div class="header-actions">
        <button class="btn-deconnexion" id="btn-logout">Se déconnecter</button>
      </div>
    </header>

    <nav class="site-nav">
      <div class="nav-item ${activeTab === "accueil" ? "active-box" : ""}">
        <a class="nav-link" href="accueil.html">🏠 Accueil</a>
      </div>

      <div class="nav-item">
        <button class="nav-link" data-toggle="frais">📋 Frais de santé <span class="nav-caret">▾</span></button>
        <div class="dropdown-panel">
          <a href="mes-paiements.html">Mes paiements</a>
          <a href="suivre-remboursements.html">Suivre mes remboursements</a>
          <a href="feuille-de-soins.html">Envoyer une feuille de soins</a>
        </div>
      </div>

      <div class="nav-item ${activeTab === "demarches" ? "open" : ""}">
        <button class="nav-link" data-toggle="demarches">📄 Démarches <span class="nav-caret">▾</span></button>
        <div class="dropdown-panel two-col">
          <div class="dd-col-left">
            <a href="#" class="active">Vos cartes</a>
            <a href="#">Frais de santé</a>
            <a href="modifier-informations.html">Modifier vos informations personnelles</a>
            <a href="arret-accident-travail.html">Arrêt / accident du travail</a>
            <a href="autres-demarches.html">Autres démarches</a>
            <a href="espace-echanges.html">Espace d'échanges</a>
          </div>
          <div class="dd-col-right">
            <a href="carte-vitale-perte.html">Déclarer la perte ou le vol de carte Vitale</a>
            <a href="carte-vitale-commander.html">Commander une carte Vitale</a>
            <a href="carte-vitale-suivi.html">Suivi de commande de carte Vitale</a>
            <a href="ceam-perte.html">Déclarer la perte ou le vol d'une carte européenne d'assurance maladie (CEAM)</a>
            <a href="ceam-commander.html">Commander une carte européenne d'assurance maladie (CEAM)</a>
          </div>
        </div>
      </div>

      <div class="nav-item ${activeTab === "cartevitale" ? "active-box" : ""}">
        <a class="nav-link" href="carte-vitale-app.html">📱 Carte Vitale</a>
      </div>

      <div class="nav-item">
        <button class="nav-link" data-toggle="documents">📁 Vos documents <span class="nav-caret">▾</span></button>
        <div class="dropdown-panel">
          <a href="attestation-droits.html">Attestation de droits</a>
          <a href="indemnites-journalieres.html">Attestation d'indemnités journalières</a>
          <a href="releves-mensuels.html">Relevés mensuels</a>
          <a href="releve-fiscal.html">Relevé fiscal</a>
        </div>
      </div>

      <div class="nav-item">
        <button class="nav-link" data-toggle="prevention">🛡️ Espace prévention <span class="nav-caret">▾</span></button>
        <div class="dropdown-panel">
          <a href="bilan-prevention.html">Mon bilan prévention</a>
          <a href="vaccination.html">Vaccination</a>
          <a href="depistages.html">Dépistages</a>
        </div>
      </div>

      <div class="nav-item ${activeTab === "infos" ? "active-box" : ""}">
        <a class="nav-link" href="vos-informations.html">👤 Vos informations</a>
      </div>
    </nav>
  `;

  mount.querySelectorAll("[data-toggle]").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const item = btn.closest(".nav-item");
      const wasOpen = item.classList.contains("open");
      document.querySelectorAll(".nav-item.open").forEach(el => el.classList.remove("open"));
      if (!wasOpen) item.classList.add("open");
      e.stopPropagation();
    });
  });
  document.addEventListener("click", () => {
    document.querySelectorAll(".nav-item.open").forEach(el => el.classList.remove("open"));
  });

  document.getElementById("btn-logout").addEventListener("click", logout);

  return user;
}
