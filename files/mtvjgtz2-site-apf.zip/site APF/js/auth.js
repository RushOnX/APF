/* ===================================================================
   auth.js — Authentification FACTICE pour le site d'entraînement.
   Aucune donnée n'est envoyée sur un réseau : tout est stocké
   uniquement dans le localStorage du navigateur de cet ordinateur.
   =================================================================== */

const USERS_KEY = "apf_atelier_users";
const SESSION_KEY = "apf_atelier_session";

const COMPTE_DEMO = {
  civilite: "Mme",
  prenom: "LEA",
  nom: "MARTIN",
  naissance: "14/03/1998",
  nir: "2 98 03 75 118 245 67",
  email: "lea.martin@exemple-atelier.fr",
  telephone: "0745821693",
  adresse: "27 rue des Peupliers, 69007 Lyon",
  motdepasse: "Atelier2024!"
};

function initUsers() {
  const existing = localStorage.getItem(USERS_KEY);
  const users = existing ? JSON.parse(existing) : [];
  const demoIndex = users.findIndex(u => u.isDemo);
  const demo = { ...COMPTE_DEMO, isDemo: true };
  if (demoIndex === -1) {
    users.push(demo);
  } else {
    users[demoIndex] = demo;
  }
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getUsers() {
  initUsers();
  return JSON.parse(localStorage.getItem(USERS_KEY));
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function findUser(email) {
  return getUsers().find(u => u.email.toLowerCase() === String(email).toLowerCase());
}

function registerUser(user) {
  const users = getUsers();
  if (findUser(user.email)) {
    return { ok: false, message: "Un compte existe déjà avec cette adresse e-mail (fictive)." };
  }
  users.push(user);
  saveUsers(users);
  return { ok: true };
}

function login(email, password) {
  const user = findUser(email);
  if (!user || user.motdepasse !== password) {
    return { ok: false, message: "Identifiant ou mot de passe incorrect." };
  }
  localStorage.setItem(SESSION_KEY, JSON.stringify({ email: user.email, since: new Date().toISOString() }));
  return { ok: true };
}

function logout() {
  localStorage.removeItem(SESSION_KEY);
  window.location.href = "index.html";
}

function getCurrentUser() {
  const session = localStorage.getItem(SESSION_KEY);
  if (!session) return null;
  const { email } = JSON.parse(session);
  return findUser(email) || null;
}

const REDIRECT_KEY = "apf_redirect_after_login";

/* À appeler en haut des pages protégées */
function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    try { sessionStorage.setItem(REDIRECT_KEY, window.location.pathname); } catch (e) {}
    window.location.href = "index.html";
  }
  return user;
}

/* Redirige vers la page initialement demandée après une connexion réussie,
   ou vers la page par défaut si aucune n'était en attente. */
function redirectAfterLogin(defaultPage) {
  let target = null;
  try {
    target = sessionStorage.getItem(REDIRECT_KEY);
    sessionStorage.removeItem(REDIRECT_KEY);
  } catch (e) {}
  window.location.href = target || defaultPage;
}

function maskPhone(tel) {
  if (!tel || tel.length < 2) return tel;
  const last2 = tel.slice(-2);
  return "** ** ** ** " + last2;
}

initUsers();
