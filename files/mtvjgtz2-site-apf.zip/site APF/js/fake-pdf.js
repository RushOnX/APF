/* ===================================================================
   fake-pdf.js — Génère de faux documents PDF réalistes pour l'atelier.
   Chaque document est clairement marqué comme fictif (filigrane +
   mentions), sans valeur légale ou administrative.
   Nécessite jsPDF (chargé via CDN dans la page).
   =================================================================== */

function genererDocumentFictif({ titre, lignes, nomFichier, avecMentionCss = false }) {
  if (typeof window.jspdf === "undefined") {
    // Repli si jsPDF n'a pas pu se charger (ex: pas de connexion internet)
    const contenu =
`====================================================
   DOCUMENT FICTIF - ATELIER DE FORMATION NUMÉRIQUE
   Ceci n'est pas un document officiel de l'Assurance Maladie
====================================================

${titre}

${lignes.join("\n")}

Document généré le ${new Date().toLocaleDateString("fr-FR")} dans le cadre
d'un atelier d'apprentissage à l'usage du site ameli.fr.
Aucune valeur légale ou administrative.
====================================================`;
    const blob = new Blob([contenu], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = nomFichier.replace(/\.pdf$/, ".txt");
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    return;
  }

  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  // --- Filigrane "DOCUMENT FICTIF" en diagonale ---
  doc.saveGraphicsState();
  doc.setTextColor(225, 225, 225);
  doc.setFontSize(46);
  doc.text("DOCUMENT FICTIF - ATELIER", 105, 160, { angle: 35, align: "center" });
  doc.restoreGraphicsState();

  // --- Bandeau d'en-tête ---
  doc.setFillColor(27, 74, 156);
  doc.rect(0, 0, 210, 24, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(15);
  doc.text("l'Assurance Maladie", 14, 11);
  doc.setFontSize(10);
  doc.text("Agir ensemble, protéger chacun — Atelier de formation numérique", 14, 18);

  // --- Bandeau d'avertissement ---
  doc.setFillColor(232, 89, 12);
  doc.rect(0, 24, 210, 9, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(9);
  doc.text(
    "CECI N'EST PAS UN DOCUMENT OFFICIEL — Exercice pédagogique, aucune valeur légale ni administrative",
    105, 30, { align: "center" }
  );

  // --- Titre ---
  doc.setTextColor(20, 20, 20);
  doc.setFontSize(18);
  doc.text(titre, 14, 46);
  doc.setDrawColor(27, 74, 156);
  doc.setLineWidth(0.8);
  doc.line(14, 50, 196, 50);

  // --- Corps du document ---
  doc.setFontSize(12);
  let y = 64;
  lignes.forEach(ligne => {
    doc.text(ligne, 14, y);
    y += 9;
  });

  if (avecMentionCss) {
    doc.setFillColor(238, 244, 251);
    doc.rect(14, y, 182, 12, "F");
    doc.setTextColor(27, 74, 156);
    doc.setFontSize(11);
    doc.text("Bénéficiaire de la Complémentaire santé solidaire (mention d'exemple)", 18, y + 8);
    y += 22;
  }

  // --- Pied de page ---
  doc.setTextColor(120, 120, 120);
  doc.setFontSize(9);
  doc.text(
    `Document généré le ${new Date().toLocaleDateString("fr-FR")} dans le cadre d'un atelier d'apprentissage`,
    14, 275
  );
  doc.text("à l'usage du site ameli.fr — aucun lien avec la Caisse nationale de l'Assurance Maladie.", 14, 280);

  doc.save(nomFichier);
}
